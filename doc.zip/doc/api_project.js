define({
  "name": "API de Projeto Transversal 2",
  "version": "1.0.0",
  "description": "Documentação sucinta referente à API do projeto!",
  "order": [
    "getValuesDifferences",
    "getWinnerCompanies",
    "getEmpresas",
    "getEmpresa",
    "getProcessos",
    "getLicitacoes",
    "getInstituicao",
    "getSuspects",
    "getSuspectedMaterials"
  ],
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-06-14T05:31:58.109Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});

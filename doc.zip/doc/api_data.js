define({ "api": [
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./doc/main.js",
    "group": "C__Users_Totow_Documents_UnB_8__Semestre_PT2_Projeto_Transversal2_master_grupo_1_doc_main_js",
    "groupTitle": "C__Users_Totow_Documents_UnB_8__Semestre_PT2_Projeto_Transversal2_master_grupo_1_doc_main_js",
    "name": ""
  },
  {
    "type": "POST",
    "url": "/get_empresa",
    "title": "get_empresa",
    "version": "1.0.0",
    "name": "getEmpresa",
    "group": "Endpoints",
    "description": "<p>Recebe como parâmetro o nome de uma empresa específica e retorna um json com as informações referentes a empresa específica, assim como o número do processo a qual está participando.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "nome_empresa",
            "description": "<p>Nome da empresa a ser pesquisada.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Processo",
            "description": "<p>Processo na qual a empresa está atuando.</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "Empresa",
            "description": "<p>Informações da empresa</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresa.nome_empresa",
            "description": "<p>Nome da empresa.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresa.valor_estimado",
            "description": "<p>Valor estimado do serviço prestado.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresa.vigencia",
            "description": "<p>Data da vigência da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresa.ata",
            "description": "<p>Ata da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresa.termo_aditivo",
            "description": "<p>Termo aditivo da Licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresa.valor_global",
            "description": "<p>Valor global da empresa na licitação.</p>"
          }
        ]
      }
    },
    "filename": "./teste.py",
    "groupTitle": "Endpoints"
  },
  {
    "type": "get",
    "url": "/get_empresas",
    "title": "get_empresas",
    "version": "1.0.0",
    "name": "getEmpresas",
    "group": "Endpoints",
    "description": "<p>Retorna um json contendo todas as informações de todas as empresas que estão no banco de dados.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "Empresas",
            "description": "<p>Lista dos empresas.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas.nome_empresa",
            "description": "<p>Nome da empresa.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas.valor_estimado",
            "description": "<p>Valor estimado do serviço prestado.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas.vigencia",
            "description": "<p>Data da vigência da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas.ata",
            "description": "<p>Ata da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas.termo_aditivo",
            "description": "<p>Termo aditivo da Licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas.valor_global",
            "description": "<p>Valor global da empresa na licitação.</p>"
          }
        ]
      }
    },
    "filename": "./teste.py",
    "groupTitle": "Endpoints"
  },
  {
    "type": "POST",
    "url": "/get_instituicao",
    "title": "get_instituicao",
    "version": "1.0.0",
    "name": "getInstituicao",
    "group": "Endpoints",
    "description": "<p>Recebe como parâmetro o nome de uma instutição específica (UnB ou Barreiras) e retorna um json com todos os dados de todas as licitações dessa instituição.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "instituicao",
            "description": "<p>Nome da instituicao a ser pesquisada.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "LicitacoesDestaInstituicao",
            "description": "<p>Licitações referentes a instituição pesquisada.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.numero_processo",
            "description": "<p>Numero do processo vigente da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.instituicao",
            "description": "<p>Instituição referida.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.pdf_url",
            "description": "<p>Link para o PDF da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.demandante",
            "description": "<p>Demandante da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.contrato",
            "description": "<p>Contrato da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.valor_total",
            "description": "<p>Valor total da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.objeto",
            "description": "<p>Objeto da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.edital",
            "description": "<p>Edital da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.classificacao",
            "description": "<p>Classificação da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.fiscal",
            "description": "<p>Fiscal da licitação e número.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.materiais_e_servicos",
            "description": "<p>SRP do Material e Serviço</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "LicitacoesDestaInstituicao.empresas",
            "description": "<p>Informações das empresas presentes nesta licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..nome_empresa",
            "description": "<p>Nome da empresa.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..valor_estimado",
            "description": "<p>Valor estimado do serviço prestado.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..vigencia",
            "description": "<p>Data da vigência da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..ata",
            "description": "<p>Ata da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..termo_aditivo",
            "description": "<p>Termo aditivo da Licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..valor_global",
            "description": "<p>Valor global da empresa na licitação.</p>"
          }
        ]
      }
    },
    "filename": "./teste.py",
    "groupTitle": "Endpoints"
  },
  {
    "type": "GET",
    "url": "/get_licitacoes",
    "title": "get_licitacoes",
    "version": "1.0.0",
    "name": "getLicitacoes",
    "group": "Endpoints",
    "description": "<p>Retorna um json contendo todas as licitações do banco de dados, mostrando todas as informações a respeito (empresas, preço, data...).</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "licitacoes",
            "description": "<p>Lista das licitações.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "licitacoes.numero_processo",
            "description": "<p>Numero do processo vigente da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "licitacoes.pdf_url",
            "description": "<p>Link para o PDF da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "licitacoes.demandante",
            "description": "<p>Demandante da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "licitacoes.contrato",
            "description": "<p>Contrato da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "licitacoes.valor_total",
            "description": "<p>Valor total da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "licitacoes.objeto",
            "description": "<p>Objeto da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "licitacoes.edital",
            "description": "<p>Edital da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "licitacoes.classificacao",
            "description": "<p>Classificação da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "licitacoes.fiscal",
            "description": "<p>Fiscal da licitação e número.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "licitacoes.materiais_e_servicos",
            "description": "<p>SRP do Material e Serviço</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "licitacoes.empresas",
            "description": "<p>Informações das empresas presentes nesta licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..nome_empresa",
            "description": "<p>Nome da empresa.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..valor_estimado",
            "description": "<p>Valor estimado do serviço prestado.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..vigencia",
            "description": "<p>Data da vigência da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..ata",
            "description": "<p>Ata da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..termo_aditivo",
            "description": "<p>Termo aditivo da Licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Empresas..valor_global",
            "description": "<p>Valor global da empresa na licitação.</p>"
          }
        ]
      }
    },
    "filename": "./teste.py",
    "groupTitle": "Endpoints"
  },
  {
    "type": "POST",
    "url": "/get_processos",
    "title": "get_processos",
    "version": "1.0.0",
    "name": "getProcessos",
    "group": "Endpoints",
    "description": "<p>Recebe como parâmetro o nome de uma empresa específica e retorna um json com apenas quais processos essa empresa está participando.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "nome_empresa",
            "description": "<p>Nome da empresa a ser pesquisada.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "NumeroDoProcesso",
            "description": "<p>Processo na qual a empresa está atuando.</p>"
          }
        ]
      }
    },
    "filename": "./teste.py",
    "groupTitle": "Endpoints"
  },
  {
    "type": "get",
    "url": "/get_suspected_materials",
    "title": "get_suspected_materials",
    "version": "1.0.0",
    "name": "getSuspectedMaterials",
    "group": "Endpoints",
    "description": "<p>Retorna todos os materiais suspeitos encontrados pelo scrapy.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "MateriaisSuspeitos",
            "description": "<p>Lista dos materiais suspeitos.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MateriaisSuspeitos.suspect_company",
            "description": "<p>Informações referentes a empresa suspeita.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MateriaisSuspeitos.suspected_product",
            "description": "<p>Nome do produto suspeito na licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MateriaisSuspeitos.date",
            "description": "<p>Data na qual a pesquisa de preços foi realizada.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "MateriaisSuspeitos.price_in_bidding",
            "description": "<p>Preso do produto na licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "MateriaisSuspeitos.more_expensive_found_product",
            "description": "<p>Informações do produto mais caro encontrado.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "more_expensive_found_product..store",
            "description": "<p>Loja onde o produto foi pesquisado.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "more_expensive_found_product..origin",
            "description": "<p>Fonte do site de shopping utilizado.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "more_expensive_found_product..price",
            "description": "<p>Preço do produto na loja pesquisada.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "more_expensive_found_product..product",
            "description": "<p>Nome do produto na loja pesquisada.</p>"
          }
        ]
      }
    },
    "filename": "./teste.py",
    "groupTitle": "Endpoints"
  },
  {
    "type": "get",
    "url": "/get_suspects",
    "title": "get_suspects",
    "version": "1.0.0",
    "name": "getSuspects",
    "group": "Endpoints",
    "description": "<p>Retorna uma lista de suspeitas (get_winner_companies) com base no tamanho das empresas, quantas que ganharam as licitações, se ganharam mais de 1 vez na mesma licitação, se ganharam no mesmo periodo de tempo....</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "Suspecious",
            "description": "<p>Lista dos suspeitos.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Suspecious.company",
            "description": "<p>Empresa suspeita.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Suspecious.suspected",
            "description": "<p>Motivo da suspeita.</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "Suspecious.wins",
            "description": "<p>Informações sobre o que a empresa ganhou na licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "wins..wonBiddings",
            "description": "<p>Informações sobre o que a empresa ganhou no pregão.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "wins..total_value",
            "description": "<p>Valor total da licitação da empresa vencedora.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "wins..number_of_wins",
            "description": "<p>Quantidade de vezes que a empresa ganhou.</p>"
          }
        ]
      }
    },
    "filename": "./teste.py",
    "groupTitle": "Endpoints"
  },
  {
    "type": "get",
    "url": "/get_vallues_differences",
    "title": "get_values_differences",
    "version": "1.0.0",
    "name": "getValuesDifferences",
    "group": "Endpoints",
    "description": "<p>Retorna um json contendo os valores de cada item extraído das licitações, com o preço unitário multiplicado pela quantidade comprada e o valor total.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "TotalValuesAnalyze",
            "description": "<p>Lista dos itens.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "TotalValuesAnalyze.File",
            "description": "<p>Item em questão.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "TotalValuesAnalyze.RealTotalValue",
            "description": "<p>Valor da licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "TotalValuesAnalyze.ExpectedAproximatedTotalValue",
            "description": "<p>Valor calculado multiplicando valor item pela quantidade.</p>"
          }
        ]
      }
    },
    "filename": "./teste.py",
    "groupTitle": "Endpoints"
  },
  {
    "type": "get",
    "url": "/get_winner_companies",
    "title": "get_winner_companies",
    "version": "1.0.0",
    "name": "getWinnerCompanies",
    "group": "Endpoints",
    "description": "<p>Retorna um json contendo quantas vezes as empresas venceram o pregão da licitação e as possíveis suspeitas.</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "WinnerCompanies",
            "description": "<p>Empresas que já venceram um pregão.</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "WinnerCompanies.IdEmpresa",
            "description": "<p>Conjunto de informações da empresa.</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "TotalValuesAnalyze..number_of_wins",
            "description": "<p>Quantidade de vitórias.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "TotalValuesAnalyze..wonBiddings",
            "description": "<p>Item ganho na licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "Number",
            "optional": false,
            "field": "TotalValuesAnalyze..total_value",
            "description": "<p>Valor total do item na licitação.</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "CompaniesThatWonMultipleTimesInTheSameBiddingWithHighValue",
            "description": "<p>Conjunto de empresas que venceram multiplas na mesma licitação com um valor alto.</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "CompaniesThatWonMultipleTimesInTheSameBiddingWithHighValue.multiple_win_companies",
            "description": "<p>Conjunto de empresas que venceram várias vezes em uma licitação. Mesmo formato que IdEmpresa</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "CompaniesThatWonMultipleTimesInTheSameBiddingWithHighValue.licitacao",
            "description": "<p>Licitação na qual as empresas em questão ganharam.</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "CompaniesThatWonMultipleTimesInAllBidding",
            "description": "<p>Empresas que ganharam várias vezes em todas as licitações. Mesmo formato que WinnerCompanies</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "CompaniesThatWonInMultipleBiddingsWithHighValue",
            "description": "<p>Empresas que ganharam em vários pregões com um valor muito alto. Mesmo formato que WinnerCompanies</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "CompaniesThatWonMultipleTimesInTheSamePeriod",
            "description": "<p>Empresas que ganharam várias vezes em no mesmo periodo. Mesmo formato que WinnerCompanies</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "CompaniesThatWonMultipleTimesInTheSameBidding",
            "description": "<p>Empresas que ganharam várias vezes em na mesma licitação. Mesmo formato que WinnerCompanies</p>"
          },
          {
            "group": "Success 200",
            "type": "String[]",
            "optional": false,
            "field": "CompaniesThatWonMultipleTimesConsideringCompanySize",
            "description": "<p>Empresas que ganharam várias vezes considerando o tamanho da empresa. Mesmo formato que WinnerCompanies</p>"
          }
        ]
      }
    },
    "filename": "./teste.py",
    "groupTitle": "Endpoints"
  }
] });
